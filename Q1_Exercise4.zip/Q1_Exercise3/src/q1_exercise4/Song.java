package q1_exercise4;

/**
 *
 * @author MUON
 */
public class Song {
    private String name;
    private boolean sing;
    public Song(){
        
    }
    public void setname(String name){
        this.name = name;
    }   
    public void setsing(boolean sing){
        this.sing = sing;
    }  
    
    public void sing(){
        System.out.println("\n" + name + " is being sung");
        sing = true;
        //Indicates the name of the song that is being played and changes its sing state
        //to true
    }
    public void stopSing(){
        System.out.println(name + " has been stopped" + "\n");
        sing = false;
        //Indicates the name of the song that has stopped playing and changes its sing state
        //to false
    }
    public String getname(){
    return name;
}
    public boolean getsing(){
    return sing;
}
    
}