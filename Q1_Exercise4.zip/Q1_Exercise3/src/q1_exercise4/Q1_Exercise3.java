/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q1_exercise4;

/**
 *
 * @author MUON
 */
public class Q1_Exercise3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MyClass Num1 = new MyClass();
        Num1.setname("Hououin Kyouma");
        Num1.setoccupation("Mad Scientist");
        Num1.setage(18);
        System.out.println("It is I, " + Num1.getname() + " I am a " + Num1.getoccupation() + " and I am " + Num1.getage());
        MyClass Num2 = new MyClass();
        Num2.setname("Makise Kurisu");
        Num2.setoccupation("Actual Scientist");
        Num2.setage(17);
        System.out.println("It is I, " + Num2.getname() + " I am an " + Num2.getoccupation() + " and I am " + Num2.getage());
        MyClass Num3 = new MyClass();
        Num3.setname("Mayuri Shiina");
        Num3.setoccupation("Mayuri");
        Num3.setage(16);
        System.out.println("It is I, " + Num3.getname() + " I am " + Num3.getoccupation() + " and I am " + Num3.getage());
        
        Song newSong = new Song(); 
        newSong.setname("One Who Craves Souls");
        newSong.setsing(false);
        newSong.sing();
        newSong.stopSing();
        Song newSong2 = new Song(); 
        newSong2.setname("Enter Hallownest");
        newSong2.setsing(false);
        newSong2.sing();
        newSong2.stopSing();
        Song newSong3 = new Song(); 
        newSong3.setname("All I Can Do");
        newSong3.setsing(false);
        
        Singer Marissa = new Singer(); 
        Marissa.setName("Marissa");
        Marissa.changeFavSong(newSong2);
        Marissa.performForAudience(12);
        Singer Daisuke = new Singer(); 
        Daisuke.setName("Daisuke");
        Daisuke.changeFavSong(newSong3);
        Daisuke.performForAudience(12, Marissa);
      
        Song newSong4 = new Song(); 
        newSong4.setname("Turbo Killer");
        newSong4.setsing(false);
        
        Marissa.changeFavSong(newSong4);
        
    }
    
}