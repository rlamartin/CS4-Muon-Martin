/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q1_exercise4;

/**
 *
 * @author MUON
 */
public class MyClass {
    private String name, occupation;
    private int age;
    
    public MyClass(){
       
        
    }
    public void setname(String name){
        this.name = name;
    }  
    public void setoccupation(String occupation){
        this.occupation = occupation;
    }  
    public void setage(int age){
        this.age = age;
    }  
    
    
    public void introduce(){
        System.out.println("It is I, " + name + " I am a " + occupation + " and I am " + age + " years old");
        //Indicates the name, occupation, and age of the inputted character
    }
      public String getname(){
        return name;
    }
    public String getoccupation(){
        return occupation;
    } 
    public int getage(){
        return age;
    }  
}