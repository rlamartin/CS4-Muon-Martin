package q1_exercise4;

/**
 *
 * @author MUON
 */
public class Singer {
        private String name;
        private  int noOfPerformances;
        private  double earnings;
        private Song favSong;
        private static int totalPerformances;
    public Singer(){
        
        this.earnings = 0;
        this.noOfPerformances = 0;
    }
    
    public void setName(String name){
        this.name = name;
    }
    public void setnoOfPerformances(int noOfPerformances){
        //this.noOfPerformances  = noOfPerformances;
        this.noOfPerformances  += noOfPerformances;
    }
    public void setfavSong(Song favSong){
        this.favSong = favSong;
    }
    public void setearnings(double earnings){
        //this.earnings  = earnings;
        this.earnings += earnings;
    }    
    
    
    
    public void performForAudience(int people){
            this.earnings = 100*people;
            this.noOfPerformances++;
            System.out.println("Earnings are " + earnings + " pesos while the number of performances are " + noOfPerformances );
        //This method calculates the earning and number of performances of the singer
            Singer.totalPerformances++;
            System.out.println("Total number of performances are " + Singer.totalPerformances );
    }
    public void performForAudience(int people, Singer duet){
            //duet.setearnings(duet.getearnings() + ((100*people)/2));
            this.earnings = (100*people)/2;
            duet.setearnings((100*people)/2);
            duet.setnoOfPerformances(1);
            this.noOfPerformances++;
            System.out.println("Earnings are " + earnings + " pesos while the number of performances are " + noOfPerformances );
        //This method calculates the earning and number of performances of the singer
            Singer.totalPerformances++;
            System.out.println("Total number of performances are " + Singer.totalPerformances );
            
            System.out.println("\n" + duet.getname() + " has: " + duet.getearnings() + " and s/he has " + duet.getnoOfPerformances() + " performance(s)" );
            System.out.println(this.getname() + " has: " + this.getearnings() + " and s/he has " + this.getnoOfPerformances() + " performance(s)" );
            
    }
    public void changeFavSong(Song favSong){
           // this.favSong = favSong;
            System.out.println(favSong.getname() + " is being played");  
            //System.out.println(this.favSong.sing);
            //Prints the sing state of the song
        }
    
    public String getname(){
    return name;
}
    public int getnoOfPerformances(){
    return noOfPerformances;
}
    public double getearnings(){
    return earnings;
}
    public Song getfavSong(){
    return favSong;
}
    public static int gettotalPerformances(){
    return totalPerformances;
}


}